import calculator

print(calculator.creator)
print(calculator.PI)
print(calculator.add(3, 5))