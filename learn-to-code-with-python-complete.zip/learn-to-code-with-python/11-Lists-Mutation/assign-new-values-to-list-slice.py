coworkers = ["Michael", "Jim", "Dwight", "Pam", "Creed", "Angela"]

# coworkers[3:5] = ["Oscar", "Ryan"]
# print(coworkers)

# coworkers[3:5] = ["Oscar"]
# print(coworkers)

# coworkers[3:5] = ["Oscar", "Ryan", "Meredith"]
# print(coworkers)

coworkers[-3:-1] = ["Ryan"]
print(coworkers)