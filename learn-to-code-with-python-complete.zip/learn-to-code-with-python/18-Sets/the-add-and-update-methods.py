disney_characters = {
    "Mickey Mouse",
    "Minnie Mouse",
    "Elsa"
}

disney_characters.add("Ariel")
print(disney_characters)

disney_characters.add("Elsa")
print(disney_characters)

disney_characters.update(["Donald Duck", "Goofy"])
print(disney_characters)

disney_characters.update(("Simba", "Pluto", "Mickey Mouse"))
print(disney_characters)