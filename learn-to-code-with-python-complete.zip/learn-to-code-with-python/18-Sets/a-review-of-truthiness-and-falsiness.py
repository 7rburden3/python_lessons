empty_list = []
stuffy_list = [1, 2, 3]

if empty_list:
    print("Empty list has items")

if stuffy_list:
    print("Stuffy list has items")

# if len(stuffy_list) > 0:
#     print("Stuffy list has items")

empty_dict = {}
stuffy_dict = { "a": 5, "b": 10 }

if empty_dict:
    print("Empty dict has key-value pairs")

if stuffy_dict:
    print("Stuffy dict has key-value pairs")

empty_set = set()
stuffy_set = (1, 2, 3)

if empty_set:
    print("Empty set has elements")

if stuffy_set:
    print("Stuffy set has elements")




