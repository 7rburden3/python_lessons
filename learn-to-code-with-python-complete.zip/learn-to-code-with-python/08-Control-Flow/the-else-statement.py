# if 20 > 15:
#     print("That is true!")
# else:
#     print("That is false!")

value = int(input("Enter a random number: "))

if value > 100000:
    print("I like that you're thinking big!")
else:
    print("That's an OK number, I guess")