zip_code = "902101"

# check
# if len(zip_code) == 5:
#     check = "Valid"
# else:
#     check = "Invalid"

check = "Valid" if len(zip_code) == 5 else "Invalid"
print(check)