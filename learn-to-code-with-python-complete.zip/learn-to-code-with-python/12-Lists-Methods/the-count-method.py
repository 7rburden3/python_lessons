car_lot = ["Ford", "Dodge", "Toyota", "Ford", "Toyota", "Chevrolet", "Ford"]

print(car_lot.count("Dodge"))
print(car_lot.count("Toyota"))
print(car_lot.count("Ferrari"))
print(car_lot.count("dodge"))

hours_of_sleep = [7.3, 7.0, 8.0, 6.5, 7.0, 8.0]

print(hours_of_sleep.count(7.3))
print(hours_of_sleep.count(7.0))
print(hours_of_sleep.count(7))