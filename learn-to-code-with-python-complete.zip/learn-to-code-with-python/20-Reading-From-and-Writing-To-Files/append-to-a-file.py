with open("my_first_file.txt", "a") as file_object:
    file_object.write("\nThird line is the best line!")