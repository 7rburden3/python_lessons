print(len("Python"))
print(len("programming"))
print(len("!@#$"))
print(len(" "))
print(len(""))

# print(len(4))
# print(len(3.14))

print("Boris" + "Paskhaver")
print("Boris " + "Paskhaver")
print("Boris" + " Paskhaver")
print("Boris" + " " + "Paskhaver")

print("a" "b" "c")

print("---" * 30)