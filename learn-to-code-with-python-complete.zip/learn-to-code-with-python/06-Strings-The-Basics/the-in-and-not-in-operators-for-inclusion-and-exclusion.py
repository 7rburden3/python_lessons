announcement = "The winners of the prize are Boris, Andy, and Adam"

print("Boris" in announcement)
print("Steven" in announcement)
print("boris" in announcement)
print(" " in announcement)
print("," in announcement)

print()

print("Boris" not in announcement)
print("Steven" not in announcement)
print("boris" not in announcement)
print(" " not in announcement)
print("," not in announcement)

