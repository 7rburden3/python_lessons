dinner = "Steak and Potatoes"

# for character in dinner:
#     print(character)

numbers = [2, 3, 5, 7, 10]

for number in numbers:
    print(number * number)

novelists = ["Fitzgerald", "Hemingway", "Steinbeck"]

for novelist in novelists:
    print(len(novelist))

print(novelist)
print(number)

total = 0

for number in numbers:
    total = total + number

print(total)