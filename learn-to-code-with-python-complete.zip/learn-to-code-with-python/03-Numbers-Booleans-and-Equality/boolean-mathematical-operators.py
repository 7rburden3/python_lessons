print(5 < 8)
print(10 < 7)
print(8 <= 8)
print(8 <= 11)
print(8 <= 7)

print(9 > 5)
print(10 > 20)
print(9 >= 9)
print(9 >= 5)
print(9 >= 10)

print(5 < 8 <= 10)
print(5 < 8 <= 7)